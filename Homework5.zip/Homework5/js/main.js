

/*function click1(){
	if (typeof(Storage) !== "undefined") {
		localStorage.setItem("first-btn-group", 1);
	} else {
		console.log("infunction");
	}
}

function click3(){
	if (typeof(Storage) !== "undefined") {
		localStorage.setItem("first-btn-group", 3);
	} else {
		console.log("infunction");
	}
}

function click6(){
	if (typeof(Storage) !== "undefined") {
		localStorage.setItem("first-btn-group", 6);
	} else {
		console.log("infunction");
	}
}

function click12(){
	if (typeof(Storage) !== "undefined") {
		localStorage.setItem("first-btn-group", 12);
	} else {
		console.log("infunction");
	}
}
*/

var selection = {'type': null, 'quantity': 0, 'glaze': 0}

function addListeners()
{
			selection.type = document.getElementById("type").innerHTML.split(" ")[0];

			var header = document.getElementById("first-btn-group");
			
			var btns = header.getElementsByClassName("btn");
			
			for (var i =0; i<btns.length;i++){
				btns[i].addEventListener("click", function() {
				
					var header = document.getElementById("first-btn-group");
				    var current = header.getElementsByClassName("active");
				    
				    if(current.length != 0){
				    current[0].className = current[0].className.replace(" active", "");
				};

				    this.className += " active";
				    selection.quantity = this.innerHTML;
				  } );	
			}

			var header = document.getElementById("second-btn-group");
			var btns = header.getElementsByClassName("btn");
			
			for (var i =0; i<btns.length;i++){
				btns[i].addEventListener("click", function() {
					
					var header = document.getElementById("second-btn-group");
				    var current = header.getElementsByClassName("active");
				    if(current.length != 0){
				    current[0].className = current[0].className.replace(" active", "");
				}
				    this.className += " active";
				    selection.glaze = this.innerHTML;
				  });	
			}

}


function addToCart() {

	var cartSt = localStorage.getItem("cart") || "[]";
	var cart = JSON.parse (cartSt);
	cart.push(selection);
	localStorage.setItem("cart", JSON.stringify(cart));

	document.getElementById("cartnumber").innerHTML = cart.length;

}


function cartTotal() {

	var cartSt = localStorage.getItem("cart") || "[]";
	var cart = JSON.parse (cartSt);
	document.getElementById("cartnumber").innerHTML = cart.length;

}

function showCart() {
	var cartSt = localStorage.getItem("cart") || "[]";
	var cart = JSON.parse (cartSt);
	var shoppingcartDiv = document.getElementsByClassName('shoppingcart')[0];

	for (var i = 0; i < cart.length; i++) {

		var itemDiv = document.createElement("div");
		itemDiv.classList.add("item");

		var imageDiv = document.createElement("div");
		imageDiv.classList.add("itemimage");

		var image = document.createElement("img");
		image.src = "images/cart1.png";

		imageDiv.appendChild(image);
		itemDiv.appendChild(imageDiv);

		var descriptDiv = document.createElement("div");
		descriptDiv.classList.add("itemdescript");

		var type = document.createElement("p");
		type.innerHTML = cart[i].type + " Cinnamon Roll";
		descriptDiv.appendChild(type);

		var quantity = document.createElement("p");
		quantity.innerHTML = cart[i].quantity;
		descriptDiv.appendChild(quantity);

		var glaze = document.createElement("p");
		glaze.innerHTML = cart[i].glaze;
		descriptDiv.appendChild(glaze);

		itemDiv.appendChild(descriptDiv);

		shoppingcartDiv.appendChild(itemDiv);

		console.log(cart[i].type + " " + cart[i].quantity + " " + cart[i].glaze);
	}
}






















/*
renderCart(){
	var cartString = localStorage.get("cart") | "[]";
	var cart. JSON.parse(cartString);
}
*/


